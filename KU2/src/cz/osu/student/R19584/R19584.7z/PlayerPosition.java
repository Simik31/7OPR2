package cz.osu.student.R19584;

public enum PlayerPosition {
    ATTACKER, DEFENDER, MIDDLE, SWEEPER, SUPPORT
}
