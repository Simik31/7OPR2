package cz.osu.student.R19584;

public enum Gender {
    MALE, FEMALE
}
