package cz.osu.student.R19584;

public enum FilterType {
    NAME_CONTAINS, POSITION_IS, IS_HIGHER_THAN, GENDER_IS, SKILL_LEVEL_IS_GREATER_THAN
}
